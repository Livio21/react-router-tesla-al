import { useLoaderData } from "@";
import { client } from "../sanity/client";
import { PortableText } from "@portabletext/react";
import { urlFor } from "";

export const loader = async ({ request }: { request: Request }) => {
  const url = new URL(request.url);
  const params = Object.fromEntries(url.searchParams);

  let sanityQuery = '*[_type == "infoPage"';

  if (params.brand && params.model) {
    sanityQuery += ` && brand == "${params.brand}" && model == "${params.model}"`;
  } else if (params.type) {
    sanityQuery += ` && serviceType == "${params.type}"`;
  } else if (params.slug) {
    sanityQuery += ` && slug.current == "${params.slug}"`;
  }

  sanityQuery += "][0]";

  const pageData = await client.fetch(sanityQuery);

  if (!pageData) return { status: 404 };

  return { pageData };
};

export default function InfoPage() {
  const { pageData } = useLoaderData();

  if (!pageData)
    return (
      <div className="text-center py-20">
        <h2>Page not found</h2>
        <p>The requested content couldn't be located</p>
      </div>
    );

  return (
    <div className="max-w-6xl mx-auto px-4 py-12">
      <header className="mb-12">
        {pageData.featuredImage && (
          <img
            src={urlFor(pageData.featuredImage).url()}
            alt={pageData.title}
            className="rounded-xl mb-6 w-full h-96 object-cover"
          />
        )}
        <h1 className="text-4xl font-bold text-white mb-2">{pageData.title}</h1>
        {pageData.brand && pageData.model && (
          <p className="text-blue-300">
            {pageData.brand} • {pageData.model}
          </p>
        )}
      </header>

      <section className="prose prose-invert max-w-none">
        <PortableText value={pageData.body} />
      </section>

      {pageData.specifications && pageData.specifications.length > 0 && (
        <section className="mt-16">
          <h2 className="text-2xl font-bold text-white mb-6">
            Technical Specifications
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {pageData.specifications.map(
              (spec: { name: string; value: string }, index: number) => (
                <div key={index} className="bg-gray-800 p-4 rounded-lg">
                  <dt className="text-blue-300 font-medium">{spec.name}</dt>
                  <dd className="mt-1 text-white">{spec.value}</dd>
                </div>
              )
            )}
          </div>
        </section>
      )}

      {pageData.gallery && pageData.gallery.length > 0 && (
        <section className="mt-16">
          <h2 className="text-2xl font-bold text-white mb-6">Gallery</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {pageData.gallery.map((image: any, index: number) => (
              <img
                key={index}
                src={urlFor(image).url()}
                alt={`Gallery item ${index + 1}`}
                className="rounded-lg object-cover h-64 w-full"
              />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
