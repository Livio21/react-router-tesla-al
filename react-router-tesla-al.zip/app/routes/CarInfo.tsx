import type { SanityDocument } from "@sanity/client";
import { Link } from "react-router";
import { client } from "~/sanity/client";
import type { Route } from "./+types/HomePage";
import { useTranslation } from "react-i18next";
import imageUrlBuilder from "@sanity/image-url";
import React, { useEffect, useRef, useState } from "react";

export default function CarInfor() {

    return(
        <>
        
        </>
    )
}
